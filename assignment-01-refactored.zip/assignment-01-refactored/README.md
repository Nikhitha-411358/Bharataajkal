# Export Software Frontend — Shipping Bill Refactor

A focused refactor of the existing Shipping Bill creation workflow. The goal is to keep the starter application's current workflow while making data access, domain validation, and submission easier to understand and replace.

## Requirements

- Node.js compatible with the Vite version in `package.json`
- pnpm
- Access to the `fe-zen-arch` Git submodule (it provides the `core`, `ui`, `auth`, and `icons` workspace packages)

## Setup

Clone the repository including its submodule:

```bash
git clone --recurse-submodules <your-private-repository-url>
cd assignment-01
pnpm install
pnpm dev
```

If you already cloned without submodules:

```bash
git submodule update --init --recursive
pnpm install
pnpm dev
```

Useful commands:

```bash
pnpm build
pnpm lint-check
```

The original starter uses the `fe-zen-arch` workspace packages. If the submodule directory is empty after downloading a ZIP, use Git clone with `--recurse-submodules`; a ZIP download does not include submodule contents.

This refactored ZIP is a source snapshot and does not contain Git history or `.git` metadata. For submission, clone/create your private GitHub repository, copy these source files into that working tree, initialize the `fe-zen-arch` submodule, review the diff, then commit and push. Do not commit your local `.env` file.

## Architecture

```text
src/shipping-bills/
  shipping-bill-form.tsx          Form UI and interaction orchestration
  model.ts                        Domain types, defaults, and payload mapping
  validation.ts                   Reusable Shipping Bill domain checks
  shipping-bill-mock-service.ts   Promise-based mock form and submit adapter
  party-mock-service.ts           Async party, branch, and port option searches
  marks-and-numbers-source.ts     Async exporter-specific option source
  shipping-bill-service.ts        HTTP adapter and flat-file download support
  demo-store.ts                   Local demo persistence and subscriptions
```

### Data flow

1. The form collects editable values using the existing form library.
2. `validation.ts` runs domain-level checks before submission.
3. The UI calls `shippingBillMockService.submit(...)`, an asynchronous service boundary that simulates a request and persists the draft to the demo store.
4. Option searches are provided by `partyMockService` and `marks-and-numbers-source.ts`; the UI handles loading and empty/error results.
5. `shipping-bill-service.ts` remains the HTTP adapter for API-backed listing and flat-file downloads. Replace the mock submit implementation with an HTTP request when a backend endpoint is available, while preserving the service contract.

Mock services intentionally keep demo data and service behavior outside UI components. No new dependencies have been added.

## Validation and domain assumptions

- Job date, exporter and branch, consignee and branch, and loading/destination ports are required.
- At least one invoice and one goods item per invoice are expected.
- Invoice number, RITC/HS code, goods description, positive quantity, and positive unit price are checked.
- If supplied, gross and net weights must be positive; net weight must not exceed gross weight.
- Total packages, if supplied, must be a non-negative whole number.
- These are pragmatic frontend checks for this exercise, not a substitute for authoritative customs/business validation.

## AI Usage & Approach

- **Tools used:** ChatGPT for code review, refactoring support, and documentation.
- **How it was used:** To identify service boundaries, centralize domain checks, and document assumptions.
- **Engineering judgment:** Existing UI, domain types, payload mapping, local demo store, and workflow were retained. The refactor avoids adding dependencies or rewriting unrelated infrastructure.
- **Validation:** Review the changes, run the app, create and edit a Shipping Bill, test invalid form values, inspect loading/empty/error states, and run the build/lint scripts before submission. AI-assisted code should be reviewed and understood by the submitter.

## Manual verification checklist

- [ ] App starts with `pnpm dev`.
- [ ] Existing Shipping Bill dashboard and editor routes still load.
- [ ] Exporter/consignee, branch, and port options can be searched.
- [ ] Changing exporter refreshes its marks-and-numbers options.
- [ ] Missing required values and invalid quantities/prices show a clear message.
- [ ] Valid submission shows success and persists a local demo record.
- [ ] Existing edit flow and flat-file download still work.
- [ ] `pnpm build` and `pnpm lint-check` pass.
