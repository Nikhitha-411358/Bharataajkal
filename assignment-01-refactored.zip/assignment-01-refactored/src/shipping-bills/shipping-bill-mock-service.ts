import { saveBill } from './demo-store'
import { emptyBill, SavedBill, ShippingBillFormValues, loadingPorts, ports } from './model'

const MOCK_LATENCY_MS = 180

function delay<T>(value: T, milliseconds = MOCK_LATENCY_MS): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(value), milliseconds))
}

export interface ShippingBillFormOptions {
  loadingPorts: typeof loadingPorts
  destinationPorts: typeof ports
  currencies: Array<{ value: string; label: string }>
}

/**
 * API-ready mock adapter for the Shipping Bill editor.
 *
 * UI components depend on these asynchronous methods rather than importing
 * hard-coded option arrays or persistence logic. Replace the implementation
 * with fetch calls when a backend is available, keeping the same interface.
 */
export const shippingBillMockService = {
  async getFormOptions(): Promise<ShippingBillFormOptions> {
    return delay({
      loadingPorts: [...loadingPorts],
      destinationPorts: [...ports],
      currencies: ['USD', 'EUR', 'INR', 'AED', 'GBP', 'SGD'].map((value) => ({ value, label: value }))
    })
  },

  async getEmptyForm(): Promise<ShippingBillFormValues> {
    return delay(emptyBill())
  },

  async submit(values: ShippingBillFormValues, existingId?: number): Promise<SavedBill> {
    // Simulate a transport/service failure without hiding it from the caller.
    // This is intentionally a local mock; no network request is made.
    await delay(null)
    if (!values.exporterId || !values.exporterBranchId) {
      throw new Error('Select an exporter and exporter branch before saving.')
    }
    if (!values.consigneeId || !values.consigneeBranchId) {
      throw new Error('Select a consignee and consignee branch before saving.')
    }
    if (!values.loadingPort || !values.finalDestinationPort) {
      throw new Error('Select both the loading and destination ports before saving.')
    }
    return saveBill(values, existingId)
  }
}
