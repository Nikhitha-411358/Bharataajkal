import { ShippingBillFormValues } from './model'

export interface ValidationIssue {
  field: string
  message: string
}

/**
 * Domain-level checks kept separate from the form schema so the same rules
 * can be reused by a future API adapter or automated tests.
 */
export function validateShippingBill(values: ShippingBillFormValues): ValidationIssue[] {
  const issues: ValidationIssue[] = []
  const required: Array<[keyof ShippingBillFormValues, string]> = [
    ['jobDate', 'Job date is required.'],
    ['exporterId', 'Select an exporter.'],
    ['exporterBranchId', 'Select an exporter branch.'],
    ['consigneeId', 'Select a consignee.'],
    ['consigneeBranchId', 'Select a consignee branch.'],
    ['loadingPort', 'Select a port of loading.'],
    ['finalDestinationPort', 'Select a final destination port.']
  ]

  for (const [field, message] of required) {
    if (!String(values[field] ?? '').trim()) issues.push({ field, message })
  }

  if (values.grossWeight && Number(values.grossWeight) <= 0) {
    issues.push({ field: 'grossWeight', message: 'Gross weight must be greater than zero.' })
  }
  if (values.netWeight && Number(values.netWeight) <= 0) {
    issues.push({ field: 'netWeight', message: 'Net weight must be greater than zero.' })
  }
  if (
    values.grossWeight &&
    values.netWeight &&
    Number(values.grossWeight) > 0 &&
    Number(values.netWeight) > Number(values.grossWeight)
  ) {
    issues.push({ field: 'netWeight', message: 'Net weight cannot exceed gross weight.' })
  }
  if (values.totalPackages && (!Number.isInteger(Number(values.totalPackages)) || Number(values.totalPackages) < 0)) {
    issues.push({ field: 'totalPackages', message: 'Total packages must be a non-negative whole number.' })
  }
  if (!values.invoices.length) {
    issues.push({ field: 'invoices', message: 'Add at least one invoice.' })
  }

  values.invoices.forEach((invoice, invoiceIndex) => {
    if (!invoice.invoiceNumber.trim()) {
      issues.push({ field: `invoices.${invoiceIndex}.invoiceNumber`, message: 'Invoice number is required.' })
    }
    if (!invoice.items.length) {
      issues.push({ field: `invoices.${invoiceIndex}.items`, message: 'Add at least one goods item.' })
    }
    invoice.items.forEach((item, itemIndex) => {
      const prefix = `invoices.${invoiceIndex}.items.${itemIndex}`
      if (!item.ritcCode.trim()) issues.push({ field: `${prefix}.ritcCode`, message: 'RITC/HS code is required.' })
      if (!item.goodsDescription1.trim()) {
        issues.push({ field: `${prefix}.goodsDescription1`, message: 'Goods description is required.' })
      }
      if (!Number.isFinite(Number(item.quantity)) || Number(item.quantity) <= 0) {
        issues.push({ field: `${prefix}.quantity`, message: 'Quantity must be greater than zero.' })
      }
      if (!Number.isFinite(Number(item.unitPrice)) || Number(item.unitPrice) <= 0) {
        issues.push({ field: `${prefix}.unitPrice`, message: 'Unit price must be greater than zero.' })
      }
    })
  })

  return issues
}
